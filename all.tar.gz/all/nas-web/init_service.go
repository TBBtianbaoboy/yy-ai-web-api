//---------------------------------
//File Name    : init_service.go
//Author       : aico
//Mail         : 2237616014@qq.com
//Github       : https://github.com/TBBtianbaoboy
//Site         : https://www.lengyangyu520.cn
//Create Time  : 2021-12-13 18:54:22
//Description  :
//----------------------------------
package nasweb

import (
	"nas-web/config"
	"nas-web/interal/cache"
	"nas-web/interal/db"
	"nas-web/middleware/jwt"
)

func InitService() bool {
	//init config file
	if err := config.ConfigInit("../confile/webapi_srv.yaml"); err != nil {
		panic(err)
	}
	//init mongo database
	db.MongoInit(config.IrisConfig.Mongodb)
	//init redis
	cache.RedisInit(config.IrisConfig.Redis)
	//init system token (avoid jwt redown)
	jwt.InitSysToken()
	//init kafka
	// if err := queue.KafkaInit(); err != nil {
	// 	panic(err)
	// }
	//init rpc client
	// if err := rpc.InitRpcForwardClient(config.IrisConfig.RpcUrl.Forward); err != nil {
	// 	return false
	// }
	return true
}
