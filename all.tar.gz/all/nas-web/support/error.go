//---------------------------------
//File Name    : error.go
//Author       : aico
//Mail         : 2237616014@qq.com
//Github       : https://github.com/TBBtianbaoboy
//Site         : https://www.lengyangyu520.cn
//Create Time  : 2021-12-14 14:35:31
//Description  :
//----------------------------------
package support

import "errors"

type NasError error

var InitRedisError NasError = errors.New("Init Redis Failed")
var InitServiceError NasError = errors.New("Init Service Failed")
var InitAppError NasError = errors.New("Init App Failed")
