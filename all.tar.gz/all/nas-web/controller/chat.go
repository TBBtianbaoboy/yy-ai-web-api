package controller

import (
	formjson "nas-web/dao/form_json"
	"nas-web/interal/wrapper"
	"nas-web/service"
	"nas-web/support"
)

type ChatController struct{}

// @Summary 发送无上下文无流式聊天
// @Description send no context no stream chat
// @Tags Chat
// @Accept json
// @Produce json
// @Param auth body formjson.SendNoContextNoStreamChatReq true "request data"
// @Success 200 {object} formjson.SendNoContextNoStreamChatResp "response data"
// @Router /v1/chat/no_context_no_stream [post]
// @Security ApiKeyAuth
// @Param Authorization header string true "authentication"
func (a ChatController) SendNoContextNoStreamChat(ctx *wrapper.Context) {
	wrapper.ApiWrapper(ctx, service.SendNoContextNoStreamChatHandler, true, &formjson.SendNoContextNoStreamChatReq{}, &wrapper.ApiConfig{ReqType: support.CHECKTYPE_JSON})
}
