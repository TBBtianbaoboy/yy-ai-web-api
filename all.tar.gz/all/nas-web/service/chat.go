package service

import (
	"encoding/json"
	"nas-common/common"
	"nas-common/mlog"
	"nas-common/models"
	formjson "nas-web/dao/form_json"
	"nas-web/dao/mongo"
	"nas-web/interal/queue"
	"nas-web/interal/scan"
	"nas-web/interal/wrapper"
	"nas-web/pkg/dispatcher"
	"nas-web/support"
	webutils "nas-web/web-utils"
	"time"

	"go.uber.org/zap"
)

// SendNoContextNoStreamChatHandler 发送无上下文无流式聊天
func SendNoContextNoStreamChatHandler(ctx *wrapper.Context, reqBody interface{}) (err error) {
	req := reqBody.(*formjson.SendNoContextNoStreamChatReq)
	resp := formjson.StatusResp{Status: "OK"}

	//新建扫描状态描述
	startTime := time.Now()
	scanStatusDesc := models.ScanStatusDesc{
		StartTime: startTime,
		ScanIp:    req.ScanIp,
		ScanType:  scan.GetScanType(req.ScanType),
		ScanId:    webutils.String.Hash(startTime.String(), req.ScanIp),
		Uid:       ctx.UserToken.UserId,
	}
	if err = mongo.Scan.Add(ctx, &scanStatusDesc); err != nil {
		mlog.Error("add scan status desc failed", zap.Error(err))
		support.SendApiErrorResponse(ctx, support.AddScanStatusDescFailed, 0)
		return nil
	}
	//将扫描信息推入消息队列
	var scanInfo models.ScanIpInfo
	scanInfo.IpDomain = req.ScanIp
	scanInfo.IpId = scanStatusDesc.ScanId
	switch req.ScanType {
	case 0:
		scanInfo.Options.Type.IsFastMode = true
	case 1:
		scanInfo.Options.Type.IsMostCommon = true
	case 2:
		scanInfo.Options.Type.PortRange = req.ScanTypeMessage
	case 3:
		scanInfo.Options.Type.PortSingle = req.ScanTypeMessage
	case 4:
		scanInfo.Options.Type.PortService = req.ScanTypeMessage
	case 5:
	default:
	}
	scanInfo.Options.IsWithServiceInfo = req.IsWithServiceInfo
	scanInfo.Options.IsWithOsDetection = req.IsWithOsDetection
	scanInfo.Options.IsWithDefaultScript = req.IsWithDefaultScript
	scanInfo.Options.IsWithTraceRoute = req.IsWithTraceRoute

	task, _ := json.Marshal(scanInfo)
	_, err = queue.DispatcherKafkaInst().SetContext(
		&dispatcher.KafkaContext{
			Topic: common.KafkaTopicZmapScanData,
		},
	).Dispatch(task)
	if err != nil {
		mlog.Error("send zmap scan task error", zap.Error(err))
	}

	support.SendApiResponse(ctx, resp, "")
	return
}

// //ListScanHandler 获取资产扫描列表
// func ListScanHandler(ctx *wrapper.Context, reqBody interface{}) (err error) {
// 	req := reqBody.(*formjson.ListScanReq)
// 	resp := formjson.ListScanResp{}
// 	query := bson.M{}
// 	sortList := make([]string, 0)
// 	if req.Sort != "" {
// 		sortList = append(sortList, req.Sort)
// 	} else {
// 		sortList = append(sortList, "-start_time")
// 	}
// 	if req.Search != "" {
// 		query["$or"] = []bson.M{
// 			{"scan_ip": bson.M{"$regex": bson.RegEx{Pattern: regexp.QuoteMeta(req.Search), Options: "i"}}},
// 		}
// 	}
// 	query["uid"] = ctx.UserToken.UserId
// 	var scanStatusDescDoc []models.ScanStatusDesc
// 	if resp.Count, scanStatusDescDoc, err = mongo.Scan.List(ctx, query, req.Page, req.PageSize, sortList...); err != nil {
// 		mlog.Error("list scan failed", zap.Error(err))
// 		support.SendApiErrorResponse(ctx, support.ListScanFailed, 0)
// 		return nil
// 	}
// 	for _, item := range scanStatusDescDoc {
// 		resp.Results = append(resp.Results, formjson.ListScanItem{
// 			ScanId:            item.ScanId,
// 			StartTime:         item.StartTime.Unix(),
// 			ScanIp:            item.ScanIp,
// 			ScanType:          item.ScanType,
// 			IsFirstScanDone:   item.IsFirstScanDone,
// 			FirstScanDoneTime: item.FirstScanDoneTime.Unix(),
// 			IsDeepScanDone:    item.IsDeepScanDone,
// 			DeepScanDoneTime:  item.DeepScanDoneTime.Unix(),
// 			Status:            item.Status,
// 		})
// 	}
// 	support.SendApiResponse(ctx, resp, "")
// 	return
// }
//
// //DeleteScanHandler delete scan items
// func DeleteScanHandler(ctx *wrapper.Context, reqBody interface{}) (err error) {
// 	req := reqBody.(*formjson.DeleteScanReq)
//
// 	for _, ScanId := range req.ScanIds {
// 		var scanItemDoc models.ScanStatusDesc
// 		if err, scanItemDoc = mongo.Scan.GetByScanID(ctx, ScanId); err != nil {
// 			continue
// 		}
// 		if ctx.UserToken.UserId != scanItemDoc.Uid {
// 			continue
// 		}
// 		if err = mongo.Scan.Delete(ctx, ScanId); err != nil {
// 			mlog.Error("delete scan item failed", zap.String("scanId", ScanId))
// 		}
// 	}
//
// 	resp := formjson.StatusResp{Status: "OK"}
// 	support.SendApiResponse(ctx, resp, "")
// 	return
// }
//
// //GetFirstScanResultHandler get first scan result
// func GetFirstScanResultHandler(ctx *wrapper.Context, reqBody interface{}) (err error) {
// 	req := reqBody.(*formjson.GetFirstScanResultReq)
// 	resp := formjson.GetFirstScanResultResp{}
// 	query := bson.M{}
// 	query["_id"] = req.ScanId
// 	var firstScanIpDoc models.FirstScanIpResult
// 	if err, firstScanIpDoc = mongo.Scan.GetFirstScanCountByID(ctx, query); err != nil {
// 		mlog.Error("get first scan result failed", zap.Error(err))
// 		support.SendApiErrorResponse(ctx, support.GetScanResultFailed, 0)
// 		return nil
// 	}
// 	var firstScanIpResultDoc models.DeepScanIpResult
// 	if err, firstScanIpResultDoc = mongo.Scan.GetFirstScanByID(ctx, query); err != nil {
// 		mlog.Error("get deep result failed", zap.Error(err))
// 		support.SendApiErrorResponse(ctx, support.GetScanResultFailed, 0)
// 		return nil
// 	}
// 	var portfb = make(map[uint16]int, 0)
// 	var servicefb = make(map[string]int, 0)
// 	resp.Count = utils.IntToString(firstScanIpResultDoc.Count)
// 	resp.All = utils.IntToString(firstScanIpDoc.Count)
// 	resp.Rate = int(float32(firstScanIpResultDoc.Count) / float32(firstScanIpDoc.Count) * 100)
// 	resp.IpDomain = firstScanIpResultDoc.DeepScanIp
// 	resp.Elapsed = firstScanIpResultDoc.Elapsed
// 	resp.StartTime = firstScanIpDoc.StartTime.Unix()
// 	resp.EndTime = firstScanIpResultDoc.EndTime.Unix()
// 	resp.ScanType = firstScanIpDoc.DeepScanOption.ScanType
// 	resp.ScanTypeMessage = firstScanIpDoc.DeepScanOption.ScanTypeMessage
// 	resp.WithOs = firstScanIpDoc.DeepScanOption.WithOs
// 	resp.WithScript = firstScanIpDoc.DeepScanOption.WithScript
// 	resp.WithService = firstScanIpDoc.DeepScanOption.WithService
// 	resp.WithTrace = firstScanIpDoc.DeepScanOption.WithTrace
// 	for _, host := range firstScanIpResultDoc.Hosts {
// 		resp.Results = append(resp.Results, formjson.DeepScanResult{
// 			Ip:           host.Addresses[0].Addr,
// 			IpType:       host.Addresses[0].AddrType,
// 			Status:       host.Status.State,
// 			StatusReason: host.Status.Reason,
// 		})
// 		for _, port := range host.Ports {
// 			if _, ok := portfb[port.ID]; ok {
// 				portfb[port.ID]++
// 			} else {
// 				portfb[port.ID] = 1
// 			}
// 			if _, ok := servicefb[port.Service.Name]; ok {
// 				servicefb[port.Service.Name]++
// 			} else {
// 				servicefb[port.Service.Name] = 1
// 			}
// 		}
// 	}
// 	resp.PortFB = portfb
// 	resp.ServiceFB = servicefb
// 	support.SendApiResponse(ctx, resp, "")
// 	return
// }
//
// //GetScanIpResultHandler get scan ip result
// func GetScanIpResultHandler(ctx *wrapper.Context, reqBody interface{}) (err error) {
// 	req := reqBody.(*formjson.GetScanIpResultReq)
// 	resp := formjson.GetScanIpResultResp{}
// 	query := bson.M{}
// 	query["_id"] = req.ScanId
// 	var firstScanIpResultDoc models.DeepScanIpResult
// 	if err, firstScanIpResultDoc = mongo.Scan.GetFirstScanByID(ctx, query); err != nil {
// 		mlog.Error("get deep result failed", zap.Error(err))
// 		support.SendApiErrorResponse(ctx, support.GetScanResultFailed, 0)
// 		return nil
// 	}
// 	for _, host := range firstScanIpResultDoc.Hosts {
// 		if host.Addresses[0].Addr == req.Ip {
// 			//port service info
// 			portServiceSum := 0
// 			for _, portService := range host.Ports {
// 				var script_tmp []formjson.ScriptInfo
// 				for _, script := range portService.Scripts {
// 					script_tmp = append(script_tmp, formjson.ScriptInfo{
// 						Id:       script.ID,
// 						Output:   script.Output,
// 						Elements: script.Elements,
// 						Tabels:   script.Tables,
// 					})
// 				}
// 				resp.PortService = append(resp.PortService, formjson.PortServiceInfo{
// 					PortId:      portService.ID,
// 					Protocol:    portService.Protocol,
// 					ServiceName: portService.Service.Name,
// 					ServiceExtraInfo: formjson.PortServiceRxtra{
// 						Version:   portService.Service.Version,
// 						Product:   portService.Service.Product,
// 						Method:    portService.Service.Method,
// 						ExtraInfo: portService.Service.ExtraInfo,
// 						Tunnel:    portService.Service.Tunnel,
// 						Cpes:      portService.Service.CPEs,
// 					},
// 					Script:       script_tmp,
// 					ServiceState: portService.State.State,
// 					ServiceTTL:   portService.State.ReasonTTL,
// 				})
// 				portServiceSum++
// 			}
// 			resp.PortServiceSum = portServiceSum
// 			//os info
// 			osGuestSum := 0
// 			for _, osG := range host.OS.Matches {
// 				resp.OsGuest = append(resp.OsGuest, formjson.OsGuestInfo{
// 					Name:  osG.Name,
// 					Value: osG.Accuracy,
// 				})
// 				osGuestSum++
// 			}
// 			resp.OsGuestSum = osGuestSum
// 			//trace info
// 			for _, trace := range host.Trace.Hops {
// 				resp.Trace = append(resp.Trace, trace.IPAddr)
// 				resp.TraceTTL = append(resp.TraceTTL, trace.TTL)
// 			}
// 			resp.TracePort = utils.IntToString(host.Trace.Port)
// 			resp.TraceProtocol = host.Trace.Proto
// 			break
// 		}
// 	}
// 	support.SendApiResponse(ctx, resp, "")
// 	return
// }
