# require tools

# protoc        v3.14.0
# protoc: http://google.github.io/proto-lens/installing-protoc.html

# protoc-gen-go v1.25.0
go get github.com/golang/protobuf/protoc-gen-go@eccd77d6ff
go get google.golang.org/grpc/cmd/protoc-gen-go-grpc
